<?php $__env->startSection('content'); ?>
    <h3>Olá, aqui estão todos os users</h3>

    

    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>

    <table class="table">
        <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Name</th>
          <th scope="col">Phone</th>
          <th scope="col">Email</th>
          <th></th>
          <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td scope="row"><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->phone); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><a href="<?php echo e(route('users.view', $user->id)); ?>" class="btn btn-info">Ver</a></td>
            <td><a href="<?php echo e(route('users.delete', $user->id)); ?>" class="btn btn-danger">Delete</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martaalmeida/Desktop/SoftDev/CESAE_SoftDev/PHP/Web_ServerSide/resources/views/users/all_users.blade.php ENDPATH**/ ?>