<?php $__env->startSection('content'); ?>

<h1>Ver / Atualizar dados <?php echo e($myUser->name); ?></h1>

<form method="POST" action="<?php echo e(route('users.update')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="id" value=<?php echo e($myUser->id); ?>>
    <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Nome</label>
        <input type="texto" value= "<?php echo e($myUser->name); ?>" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Nome" required>
        <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                O nome que colocou é inválido.
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Email</label>
        <input disabled type="email" value="<?php echo e($myUser->email); ?>" name="email" class="form-control" id="exampleFormControlInput1" placeholder="email@exemplo.com" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                O email que colocou já está registado.
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Morada</label>
        <input type="texto" value= "<?php echo e($myUser->address); ?>" name="address" class="form-control" id="exampleFormControlInput1">
        <?php $__errorArgs = ["address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                A morada que colocou é inválida.
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="mb-3">
        <label for="exampleFormControlInput1" class="form-label">Telefone</label>
        <input type="texto" value= "<?php echo e($myUser->phone); ?>" name="phone" class="form-control" id="exampleFormControlInput1">
        <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                O telefone que colocou é inválido.
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <button type="submit" class="btn btn-primary">Atualizar</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martaalmeida/Desktop/SoftDev/CESAE_SoftDev/PHP/Web_ServerSide/resources/views/users/view.blade.php ENDPATH**/ ?>