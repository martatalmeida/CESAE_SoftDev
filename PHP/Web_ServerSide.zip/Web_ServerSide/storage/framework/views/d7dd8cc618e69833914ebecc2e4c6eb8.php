<?php $__env->startSection('content'); ?>

    <h2>Todas as Tarefas</h2>

    <?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?>

    <table class="table">
        <thead>
        <tr>
          <th scope="col">Name</th>
          <th scope="col">Status</th>
          <th scope="col">Data Conclusão</th>
          <th scope="col">Pessoa Responsável</th>
          <th></th>
          <th></th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td scope="row"><?php echo e($task->name); ?></th>
            <td><?php echo e($task->status); ?></td>
            <td><?php echo e($task->due_at); ?></td>
            <td><?php echo e($task->PessoaResponsavel); ?></td>
            <td><a href="<?php echo e(route('tasks.view_task', $task->id)); ?>" class="btn btn-info">Ver</a></td>
            <td><a href="<?php echo e(route('tasks.delete', $task->id)); ?>" class="btn btn-danger">Delete</a></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martaalmeida/Desktop/SoftDev/CESAE_SoftDev/PHP/Web_ServerSide/resources/views/tasks/all_tasks.blade.php ENDPATH**/ ?>