    

    <?php $__env->startSection('content'); ?>
        <h2>Hello World, estamos nas Views.</h2>

        <h5>Tens disponíveis estes links:</h5>

        <ul>
            <li><a href="<?php echo e(route('bemvindos')); ?>">Vai para casa!</a></li>
            <li><a href="<?php echo e(route('users.add')); ?>">Aqui podes adicionar utilizadores</a></li>
            <li><a href="<?php echo e(route('users.all')); ?>">Aqui podes ver todos os users</a></li>
        </ul>

        <h3>Dados do Cesae</h3>
        <p>Nome: <?php echo e($cesaeInfo['name']); ?></p>
        <p>Morada: <?php echo e($cesaeInfo['address']); ?></p>
        <p>Email: <?php echo e($cesaeInfo['email']); ?></p>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content2'); ?>
        <p>segundo conteudo</p>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\softdev\Desktop\MartaAlmeida_SoftDev\PHP\Web_ServerSide\resources\views/main/home.blade.php ENDPATH**/ ?>