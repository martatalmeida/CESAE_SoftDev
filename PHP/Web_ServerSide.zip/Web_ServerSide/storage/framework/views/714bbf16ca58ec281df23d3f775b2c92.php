<?php $__env->startSection('content'); ?>
    <h2>Ups, estás perdido</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content2'); ?>
<h3><a href="<?php echo e(route('bemvindos')); ?>">Volta para casa</a></h3>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\softdev\Desktop\MartaAlmeida_SoftDev\PHP\Web_ServerSide\resources\views/main/fallback.blade.php ENDPATH**/ ?>