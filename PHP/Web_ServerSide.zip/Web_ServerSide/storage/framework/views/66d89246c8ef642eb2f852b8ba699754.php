<?php $__env->startSection('content'); ?>
    <h3>Olá, aqui estão todos os users</h3>

    <p><?php echo e($hello); ?></p>
    <p><?php echo e($helloAgain); ?></p>
    <p><?php echo e($daysOfWeek[2]); ?></p>
    <p><?php echo e($info['name']); ?></p>
    <p><?php echo e($info['modules'][0]); ?></p>
    <p><?php echo e($info[0][2]); ?></p>

    <table class="table">
        <thead>
        <tr>
          <th scope="col">ID</th>
          <th scope="col">Name</th>
          <th scope="col">Phone</th>
          <th scope="col">Email</th>
        </tr>
        </thead>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
          <tr>
            <th scope="row"><?php echo e($user['id']); ?></th>
            <td><?php echo e($user['name']); ?></td>
            <td><?php echo e($user['phone']); ?></td>
            <td><?php echo e($user['email']); ?></td>
          </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\softdev\Desktop\MartaAlmeida_SoftDev\PHP\Web_ServerSide\resources\views/users/all_users.blade.php ENDPATH**/ ?>