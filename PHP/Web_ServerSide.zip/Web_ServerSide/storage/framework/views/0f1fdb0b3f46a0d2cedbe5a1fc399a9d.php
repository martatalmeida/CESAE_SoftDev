<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Adicionar Utilizadores</title>
</head>
<body>
    <h2>Olá, aqui podes Adicionar Utilizadores</h2>
</body>
</html>
<?php /**PATH C:\Users\softdev\Desktop\MartaAlmeida_SoftDev\PHP\Web_ServerSide\resources\views/utilizador/utilizadores.blade.php ENDPATH**/ ?>