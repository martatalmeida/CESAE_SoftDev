<?php $__env->startSection('content'); ?>
    <br>
    <h2>Olá, aqui podes Adicionar Tarefas</h2>
    <br>


    <form method="POST" action="<?php echo e(route('tasks.create')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Nome</label>
            <input type="texto" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Nome"
                required>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    O nome que colocou não segue os requisitos.
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Descrição</label>
            <input type="text" name="description" class="form-control" id="exampleFormControlInput1" placeholder=""
                required>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger">
                    A descrição que colocou não segue os requisitos.
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">

            <select class="custom-select" name="user_id">
                <option selected> Todos os Users</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php if($item->id == request()->query('user_id')): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                        <?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>
        <button type="submit" class="btn btn-primary">Enviar</button>
    </form>
    <br>
    <a class="btn btn-success" href="<?php echo e(route('tasks.all')); ?>">Voltar</a>
    <br>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martaalmeida/Desktop/SoftDev/CESAE_SoftDev/PHP/Web_ServerSide/resources/views/tasks/add_task.blade.php ENDPATH**/ ?>