<?php $__env->startSection('content'); ?>

<h1>Ver uma Task</h1>


<h4>Nome: <?php echo e($myTask->name); ?></h4>
<h4>Description: <?php echo e($myTask->description); ?></h4>
<h4>Due at: <?php echo e($myTask->due_at); ?></h4>
<h4>Status: <?php echo e($myTask->status); ?></h4>
<h4>User: <?php echo e($myTask->user_id); ?></h4>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.femaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/martaalmeida/Desktop/SoftDev/CESAE_SoftDev/PHP/Web_ServerSide/resources/views/tasks/view.blade.php ENDPATH**/ ?>