@extends('layouts.femaster')

@section('content')
    <h2>Ups, estás perdido</h2>
@endsection

@section('content2')
<h3><a href="{{route('bemvindos')}}">Volta para casa</a></h3>
@endsection
