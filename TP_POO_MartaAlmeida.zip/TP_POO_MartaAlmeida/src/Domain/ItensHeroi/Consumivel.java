package Domain.ItensHeroi;

import Domain.ItensHeroi.ItemHeroi;

public class Consumivel extends ItemHeroi {

    public Consumivel(String nome, int precoMoedasOuro) {
        super(nome, precoMoedasOuro);
    }


}


